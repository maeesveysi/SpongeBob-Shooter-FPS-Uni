=======================================================================================================

Ripped and posted by CrispyShroom
Transparency alpha textures by CrispyShroom
All other unmentioned models and textures were made by Heavy Iron Studios®

========================================================================================================

OBJ model:
The following materials with transparent textures will need their alpha counterparts manually readded:

mat_fountain_water
mat_grass_clump
mat_grass_edge_ver2
mat_ground_cobble_ver2
mat_hb01_shadow_KK
mat_hb01_shadow_mesa
mat_house_sb_flowers01
mat_house_sb_flowers02
mat_jf_sky_flowers
mat_kf_lodtextures_fringes
mat_krustykrab_net
mat_robot_headquarters
mat_sand_crater_3
mat_shadow_generic_ver2
mat_sign_jellyfish
mat_toll_paint_stroke
mat_treeleavealf

========================================================================================================
The DAE and FBX models do not need their alpha textures manually readded to the respected materials.

Additionally, the DAE or FBX files are the recommended file format to use as they have the meshes
organized into groups/layers while OBJ does not have that capability.
========================================================================================================